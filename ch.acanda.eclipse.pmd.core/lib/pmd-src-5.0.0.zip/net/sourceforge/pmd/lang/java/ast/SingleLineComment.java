package net.sourceforge.pmd.lang.java.ast;

public class SingleLineComment extends Comment {

    public SingleLineComment(Token t) {
        super(t);
    }

}
