package net.sourceforge.pmd.lang.java.rule.comments;
/**
 * 
 * @author Brian Remedios
 */
public class CodeInCommentsRule extends AbstractCommentRule {

//	private static final char[] SingleCharsAsCode = new char[] {'{', '}'};
//	private static final char[] LastCharTerminatorAsCode = new char[] { '{', '}', ';' };
	
	public CodeInCommentsRule() {
		// TODO Auto-generated constructor stub
	}

}
