package net.sourceforge.pmd.lang.ast;

/**
 * This interface can be used to tag the root node of various ASTs.
 */
public interface RootNode {
}
